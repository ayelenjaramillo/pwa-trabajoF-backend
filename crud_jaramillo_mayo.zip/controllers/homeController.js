const {Producto} = require("../database/models")

const homeController = {
    index: (req, res)=>{
        res.render("index", { 
            titulo: "TP CRUD | Jaramillo Ayelén ", 
               
        })
    },
    notFound: (req, res)=>{
        res.status(404).render("404", {
            h1: "pagina no encntrada"
        })
    }
}

module.exports = homeController;