const { Proyecto, Categoria, Escuela } = require("../../database/models");

const proyectoController = {
  todos: async (req, res) => {
    try {
      const proyecto = await Proyecto.findAll({
        include: [
          { model: Categoria, as: "categoria" },
          { model: Escuela, as: "escuela" },
        ],
      });
      res.render("./proyectos/proyectos", {
        titulo: "Mirá todos los proyectos",
        proyecto,
      });

      //    res.json(proyecto)
    } catch (error) {
      res.redirect("/proyectos");
    }
  },
  detalleProyecto: async (req, res) => {
    const id = req.params.id;
    try {
      const proyecto = await Proyecto.findByPk(id, {
        include: [
          { model: Categoria, as: "categoria" },
          { model: Escuela, as: "escuela" },
        ],
      });
      res.render("./proyectos/proyecto", {
        titulo: `Proyecto: ${proyecto.titulo}`,
        proyecto,
      });
    } catch (error) {
      res.redirect("/proyectos");
    }
  },
  formNuevo: async (req, res) => {
    const categorias = await Categoria.findAll();
    const escuelas = await Escuela.findAll();
    res.render("./proyectos/nuevo", {
      titulo: "Subí tu proyecto",
      categorias,
      escuelas,
    });
  },
  crearNuevo: async (req, res) => {
    const { titulo, descripcion, categoria_id, escuela_id } = req.body;
    

    try {
      const imagenes = req.files && req.files.length > 0 ? req.files.map(file => file.filename).join(",") : null;

      await Proyecto.create({
        titulo,
        descripcion,
        categoria_id,
        escuela_id,
        imagenes,
      }); 
      res.redirect("/proyectos");
    } catch (error) {
      res.redirect("/proyectos/nuevo");
    }
  },
  editar: async (req, res) => {
    const id = req.params.id;
    try {
      const proyecto = await Proyecto.findByPk(id);
      const categorias = await Categoria.findAll();
      const escuelas = await Escuela.findAll();
      // console.log( "Proyecto: ", JSON.stringify(proyecto, null, 4));
      if (!proyecto) {
        return res.redirect("/proyectos");
      }
      res.render("./proyectos/editar", {
        titulo: "Editando",
        proyecto,
        categorias,
        escuelas,
      });
    } catch (error) {
      res.redirect("/proyectos");
    }
  },
  update: async (req, res) => {
    const id = req.params.id;
    try {
      const proyecto = await Proyecto.findByPk(id);
      if (!proyecto) {
        return res.redirect("/proyectos");
      }
      const { titulo, descripcion, escuela_id, categoria_id } = req.body;
      const imagen = req.file ? req.file.filename : Proyecto.imagen;

      const nuevo = {
        titulo,
        descripcion,
        escuela_id,
        categoria_id,
        imagen,
      };
      await Proyecto.update(nuevo, {
        where: {
          id: id,
        },
      });
      res.redirect(`/proyectos/${proyecto.id}`);
    } catch (error) {
      res.redirect("/proyectos");
    }
  },
  eliminarProyecto: async (req, res) => {
    const id = req.params.id;
    try {
      const proyecto = await Proyecto.findByPk(id);
      if (!proyecto) {
        return res.redirect("/proyectos");
      }
      await proyecto.destroy();
      res.redirect("/proyectos");
    } catch (error) {
      res.redirect("/proyectos");
    }
  },
};

module.exports = proyectoController;
